package outerlayer.userinterface.registeruserinterface;

import outerlayer.userinterface.FilePathHelper;

public class RegiserUITest {
    public static void main(String[] args){
        String file_path = FilePathHelper.FILEPATH + "/user.csv";
        int ID = 0;
        RegisterUI.registerUi();
    }
}
