package outerlayer.userinterface.facultyuserinterface;


public class FacultyUITest {
    public static void main(String[] args){
        FacultyUI.loadData();
        FacultyUI.facultyPage();
    }
}
