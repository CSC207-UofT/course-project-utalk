package usecase.creator;

public class CreatorTest {
    public static void main(String[] args){
        UserRegister.registerUser("1","Judd","123","student","1");

        UserRegister.registerUser("1","Zhang","123","student","1");

        UserRegister.registerUser("1","Paul","123","professor","1");
    }

}
