import interfaceadaptor.loginlogout.Login;

public class LoggedInUserTest {
    public static void main (String[] args){
        Login.logIn();

    }
}
