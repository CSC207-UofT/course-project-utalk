package outerlayer.userinterface;

public class FilePathHelper {
    public static final String FILEPATH = "D:\\2021Fall\\CSC207\\IdeaProjects\\course-project-utalk-13\\src\\edu\\main\\outerlayer\\database\\";
}
